/* Taylor Boyles
   CPSC 1111, spring 2021
   lab 10
   description: this file contains the function that converts decimal numbers to
   binary

*/


int dtob(int inputDec){ // function to convert decimal to binary

    int bin[32]; // allows the array to store 32 bits
    int i= 0;

    while(inputDec > 0){ //while loop that devides the number while inoputDec is greater than 0
        bin[i] = inputDec % 2; // stores remainder in an array
        inputDec /= 2; // devides the user input by two
        i++;
    }

    int ans = 0;// convert the int array into a number
    int a;
    for(a=i-1;a >= 0;a--){
        ans = ans*10 + bin[a];
    }
    return ans;
}
