/* Taylor Boyles
   CPSC 1111, spring 2021
   lab 10
   description: this file contains the function that converts binary numbers to
   decimal

*/

int btod(int size, char inputBin[size]){ // function to convert binary to a decimal
    int ans = 0;
    int count = 1;
    int i;

    for(i=size-1;i>=0;i--){// converting binary character arrary to decimal
        ans += count*(inputBin[i] - '0');
        count *= 2;
    }
    return ans;
}
