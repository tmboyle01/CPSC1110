/* Taylor Boyles
   CPSC 1111, spring 2021
   lab 10
   description: the purpose of this lab is to convert binary numbers to Decimal,
   and decimal numbers to binary using two seperate functions, while also using
   header files and seperate c files.

*/

#include<stdio.h>
#include<string.h>

#include "btod.h"
#include "dtob.h"



int main(){

    int num;
    printf("Enter a decimal number: ");
    scanf("%d", &num);
    int bin = dtob(num); // calls the function that converts num to a binary number
    printf("The binary equivalent is: %d\n", bin); //prints teh converted num in bin


    char input[32]; // allows the array to store 32 bits
    printf("Enter a binary number: ");
    scanf("%s", input);
    int len = strlen(input); // returns the length of the string inpout
    int dec = btod(len, input); // calls the function that converts the binary number to dicimal
    printf("the decimal equivalent is: %d \n", dec);// prints the converted bin number in decimal

}
