/* Taylor Boyles
   CPSC 1111, spring 2021
   lab 10
   description: this header file contains the prototype for the decimal to
   binary function

*/

int dtob(int inputDec);
